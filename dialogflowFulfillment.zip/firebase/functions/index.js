// See https://github.com/dialogflow/dialogflow-fulfillment-nodejs
// for Dialogflow fulfillment library docs, samples, and to report issues
'use strict';
 
const functions = require('firebase-functions');
const {WebhookClient} = require('dialogflow-fulfillment');
const {Card, Suggestion} = require('dialogflow-fulfillment');
const axios = require('axios');
const { BasicCard, Button, Image, List, Suggestions,LinkOutSuggestion } = require('actions-on-google');
 
process.env.DEBUG = 'dialogflow:debug'; // enables lib debugging statements
 
exports.dialogflowFirebaseFulfillment = functions.https.onRequest((request, response) => {
  const agent = new WebhookClient({ request, response });
  console.log('Dialogflow Request headers: ' + JSON.stringify(request.headers));
  console.log('Dialogflow Request body: ' + JSON.stringify(request.body));
 
  function welcome(agent) {
    agent.add(`Welcome to my agent!`);
  }
 
  function fallback(agent) {
    agent.add(`I didn't understand`);
    agent.add(`I'm sorry, can you try again?`);
  }
  
  function recommendation(agent) {
  	return axios.get('http://35.247.182.159/books/popular').then(({data}) => {
      let temp = [];
      agent.requestSource = agent.ACTIONS_ON_GOOGLE;
      let conv = agent.conv();
      conv.ask('This is our recommendation');
      for (let i = 0; i < 3; i ++) {
      	//temp.push(data[i].title)
         conv.ask(
        new BasicCard({
            subtitle: `Written by: ${data[i].author.join(', ')}`,
            title: `${data[i].title}`,
            buttons: [
                new Button({ title: 'Order Now !', url: `https://hackbook.dipaproject.online/home/products/${data[i]._id}` })
            ],
         })
        );
        //conv.ask(new Suggestions(data[i].title));
      }
      agent.add(conv);
    	//agent.add(`Our book recommendations are ${temp.join(', ')}`)
    })
    .catch (() => {
    	agent.add('Sorry, our server offline');
    });
  }
  
  function convertToRupiah (number) {
    let rupiah = '';
    let numberrev = number.toString().split('').reverse().join('');
    for(let i = 0; i < numberrev.length; i++) if(i%3 == 0) rupiah += numberrev.substr(i,3)+'.';
    return rupiah.split('',rupiah.length-1).reverse().join('')
  }

  function searchTitle(agent) {
  agent.requestSource = agent.ACTIONS_ON_GOOGLE;
  let conv = agent.conv();
  return axios.get(`http://35.247.182.159/books/book-title?title=${request.body.queryResult.parameters.title}`)
  .then (({data}) => {
    if (data.length > 0) {
      conv.ask(`I Found Books with title ${request.body.queryResult.parameters.title}`);
     //or (let i = 0; i < data.length; i++) {
   //   if (data[i].price <200){
    //  	data[i].price = data[i].price * 15000
   //   }
       //onv.ask(
        //new BasicCard({
       //   text: `Price: Rp ${data[i].price}, stock: ${data[i].stock}`,
       //   image: new Image({
       //     url:
       //       `${data[i].image}`,
       //     alt: 'Bot banner'
        //  }),
       //   subtitle: `${data[i].author.join(', ')}`,
       //   title: `${data[i].title}`
        //})
      //);
    //}
            conv.ask(
          new LinkOutSuggestion({
              name: `Details to your books`,
              url: `https://hackbook.dipaproject.online/home/search/${request.body.queryResult.parameters.title}`
          })
      );
      agent.add(conv);
    } else {
      agent.add(`Sorry, I couldn't find book with title ${request.body.queryResult.parameters.title}`);
    }
  })
  .catch (() => {
    agent.add('Sorry, our server offline');
  });
}
  
  function searchCategory(agent) {
  agent.requestSource = agent.ACTIONS_ON_GOOGLE;
  let conv = agent.conv();
  return axios.get(`http://35.247.182.159/books/book-category?category=${request.body.queryResult.parameters.category}`)
  .then (({data}) => {
    if (data.length > 0) {
      conv.ask(`I Found Books in Category ${request.body.queryResult.parameters.category}`);
      conv.ask(
          new LinkOutSuggestion({
              name: `Details to your books`,
              url: `https://hackbook.dipaproject.online/home/search/${request.body.queryResult.parameters.category}`
          })
      );
      agent.add(conv);
    } else {
      agent.add(`Sorry, I couldn't find book in category ${request.body.queryResult.parameters.category}`);
    }
  })
  .catch (() => {
    agent.add('Sorry, our server is offline');
  });
}
  
function searchAuthor(agent) {
  agent.requestSource = agent.ACTIONS_ON_GOOGLE;
  let conv = agent.conv();
  return axios.get(`http://35.247.182.159/books/book-author?author=${request.body.queryResult.parameters.author}`)
  .then (({data}) => {
    if (data.length > 0) {
      conv.ask(`I Found Books Written by ${request.body.queryResult.parameters.author}`);
      //for (let i = 0; i < data.length; i++) {
        //if (data[i].price <200){
        //	data[i].price = data[i].price * 15000
       // }
        //conv.ask(
         // new BasicCard({
            //text: `Price: Rp ${data[i].price}, stock: ${data[i].stock}`,
           // image: new Image({
            //  url:
             //   `${data[i].image}`,
            //  alt: 'Bot banner'
           // }),
            //subtitle: `${data[i].author.join(', ')}`,
            //title: `${data[i].title}`
        //  })
       // );
        conv.ask(
          new LinkOutSuggestion({
              name: `Details to your books`,
              url: `https://hackbook.dipaproject.online/home/search/${request.body.queryResult.parameters.author}`
          })
      );
     // }
      
      agent.add(conv);
    } else {
      agent.add(`Sorry, I couldn't find book written by ${request.body.queryResult.parameters.author}`);
    }
  })
  .catch (() => {
    agent.add('Sorry, our server is offline');
  });
}
  
  function listCategory(agent) {
    agent.requestSource = agent.ACTIONS_ON_GOOGLE;
    let conv = agent.conv();
    return axios.get('http://35.247.182.159/books/get-categories').then (({data}) => {
    	conv.ask('This is available categories');
        for (let i = 0; i < data.length; i ++) {
           conv.ask(`Category: ${data[i].category}`);
        }
        agent.add(conv);
    })
    .catch (() => {
    	agent.add('Sorry, our server is offline');
    });
  }
  
  function Test (agent) {
  	agent.requestSource = agent.ACTIONS_ON_GOOGLE;
  	let conv = agent.conv();
    conv.ask(`I Found Books Written by `);
    conv.ask(
          new BasicCard({
            text: `Price: Rp 10000 stock: 20`,
            image: new Image({
              url:
                `https://www.w3schools.com/w3css/img_snowtops.jpg`,
              alt: 'Bot banner'
            }),
            subtitle: `test`,
            title: `test`,
            buttons: [
              new Button({ title: 'Test Button', url: 'https://hacktiv8.com/' }),
              new Button({ title: 'Test Button 2', url: 'www.botcopy.com' })
            ],
          })
        );
    for (let i = 0; i <2; i ++) {
    	conv.ask(
		new LinkOutSuggestion({
			name: 'Title of Link Out',
			url: 'http://bdbb0086.ngrok.io'
		})
	);
    }
    
    agent.add(conv);
  }
  
  function personality(agent) {
    agent.requestSource = agent.ACTIONS_ON_GOOGLE;
  	let conv = agent.conv();
    let arrTemp = [];
    if (request.body.queryResult.parameters.mood === 'happy') {
      arrTemp.push('Mind');
      arrTemp.push('Fiction');
      arrTemp.push('Reference');
      arrTemp.push('Humor');
  //  arrTemp.push('Anxiety');
      arrTemp.push('Drama');
      let numRan = Math.round(Math.random());
      if (numRan === 0) {
        conv.ask(" I’m also happy that you feel great");
        conv.ask(" Here’s my recommendation to make your day much even better");
      } else {
		conv.ask("I’m happy to hear that");
        conv.ask("Here’s a book from me to make your day much even better");
      }
    }
    
    if (request.body.queryResult.parameters.mood === 'sad') {
      arrTemp.push('Body, Mind & Spirit');
      arrTemp.push('Humor');
      arrTemp.push('Mind');
      arrTemp.push('Conduct of life');
      arrTemp.push('Psychology');
      let numRan = Math.round(Math.random());
      if (numRan === 0){
        conv.ask(" Everyone had a bad day");
      	conv.ask("Hope this book make your smile blossom");
      } else {
        conv.ask(" If you’re feeling sad, don’t worry ! ");
      	conv.ask(" I have something to cheer you up, check this book out");
      }
     }
    
    if (request.body.queryResult.parameters.mood === 'calm') {
      arrTemp.push('Drama');
      arrTemp.push('Consciousness');
      arrTemp.push('Juvenile Nonfiction');
      arrTemp.push('Fiction');
      arrTemp.push('Philosophy');
      let numRan = Math.round(Math.random());
      if (numRan === 0) { 
        conv.ask("You want some exciting experiences ?");
        conv.ask("Try this book ! ");
      } else { 
        conv.ask("Feeling bored yet ?");
        conv.ask("Check this out !");
      }
    }
    
    if (request.body.queryResult.parameters.mood === 'angry') {
      arrTemp.push('Body, Mind & Spirit');
      arrTemp.push('Humor');
      arrTemp.push('Mind');
      arrTemp.push('Conduct of life');
      arrTemp.push('Health & Fitness');
      arrTemp.push('Family & Relationships');
      let numRan = Math.round(Math.random());
      if (numRan === 0) {
        conv.ask("It looks like you need some entertainment");
      	conv.ask("Here’s my recommendation to make you feel better");
      } else { 
        conv.ask("I guess you need more relaxation time ");
    	conv.ask("Try this book out")
        }
      }
    
    if (request.body.queryResult.parameters.mood === 'disappointed') {
      arrTemp.push('Body, Mind & Spirit');
      arrTemp.push('Humor');
      arrTemp.push('Mind');
      arrTemp.push('Conduct of life');
      arrTemp.push('Psychology');
      let numRan = Math.round(Math.random());
      if (numRan === 0) {
        conv.ask("Everyone made a mistake in life ");
      	conv.ask("You might learn new perspective from this book");
      } else {
        conv.ask("Human learn from mistakes ");
      	conv.ask("You might learn something from this");
      }
    }
    
    if (request.body.queryResult.parameters.family === 'yes') {
      arrTemp.push('Childrens');
      arrTemp.push(`Children's stories`);
      arrTemp.push('Family & Relationships');
      arrTemp.push('FAMILY & RELATIONSHIPS');
    }
    
	if (request.body.queryResult.parameters.literature === 'yes') {
      arrTemp.push('Arts');
      arrTemp.push(`Philosophy`);
      arrTemp.push('Religion');
      arrTemp.push('Antiques & Collectibles');
      arrTemp.push('Fathers and daughters in literature');
      arrTemp.push('Literary Collections');
      arrTemp.push('Literary Criticism');
    }
    
    if (request.body.queryResult.parameters.cooking === 'yes') {
      arrTemp.push('Cooking');
      arrTemp.push(`Food`);
      arrTemp.push('Agriculture');
      arrTemp.push('Diet');
    }
    
    if (request.body.queryResult.parameters.economy === 'yes') {
      arrTemp.push(`Political Science`);
      arrTemp.push('Law');
      arrTemp.push('Business & Economics');
    }
    
    if (request.body.queryResult.parameters.fiction === 'yes') {
      arrTemp.push('Alabama');
      arrTemp.push(`Arts`);
      arrTemp.push(`Music`);
      arrTemp.push('Architecture');
      arrTemp.push('Photography');
    }
    
    if (request.body.queryResult.parameters.health === 'yes') {
      arrTemp.push('Diet');
      arrTemp.push(`Health & Fitness`);
      arrTemp.push(`Medical`);
      arrTemp.push('Psychology');
    }
    
    if (request.body.queryResult.parameters.history === 'yes') {
      arrTemp.push('History');
      arrTemp.push(`Political Science`);
      arrTemp.push('Imperialism');
    }
    
    if (request.body.queryResult.parameters.science === 'yes') {
      arrTemp.push('Reference');
      arrTemp.push(`Technology`);
      arrTemp.push('Mathematics');
      arrTemp.push('Technology & Engineering');
      arrTemp.push('Computer');
      arrTemp.push('Education');
      arrTemp.push('Language Arts & Disciplines');
    }
    
    let number = Math.floor(Math.random()*arrTemp.length);
    //conv.ask(`You might like this book 🙋`);
    return axios.get(`http://35.247.182.159/books/book-category?category=${arrTemp[number]}`)
    .then (({data}) => {
    	let random = Math.floor(Math.random()*data.length);
      	let temp = data[random];
      	conv.ask(
        new BasicCard({
            text: `Price: Rp ${convertToRupiah(data[random].price)}, stock: ${data[random].stock}`,
            image: new Image({
            url:
               `${data[random].image}`,
            alt: 'Bot banner'
            }),
            subtitle: `${data[random].author.join(', ')}`,
            title: `${data[random].title}`,
            buttons: [
                new Button({ title: 'Order Now !', url: `https://hackbook.dipaproject.online/home/products/${data[random]._id}` })
            ],
         })
        );
      	//conv.ask(
          //new LinkOutSuggestion({
            //  name: `Order your books now !`,
              //url: `https://hackbook.dipaproject.online/home/products/${data[random]._id}`
          //})
          //);
        agent.add(conv);
        })
    .catch (() => {
    	agent.add('Sorry our server offline');
    });
    
  //agent.add(`${request.body.queryResult.parameters.mood} + 
	//${request.body.queryResult.parameters.family} +
	//${request.body.queryResult.parameters.literature} +
	//${request.body.queryResult.parameters.cooking} + 
	//${request.body.queryResult.parameters.economy} +
	//${request.body.queryResult.parameters.fiction} +
	//${request.body.queryResult.parameters.health} + 
	//${request.body.queryResult.parameters.history} + 
	//${request.body.queryResult.parameters.science}`);
 }
  // // Uncomment and edit to make your own intent handler
  // // uncomment `intentMap.set('your intent name here', yourFunctionHandler);`
  // // below to get this function to be run when a Dialogflow intent is matched
  // function yourFunctionHandler(agent) {
  //   agent.add(`This message is from Dialogflow's Cloud Functions for Firebase editor!`);
  //   agent.add(new Card({
  //       title: `Title: this is a card title`,
  //       imageUrl: 'https://developers.google.com/actions/images/badges/XPM_BADGING_GoogleAssistant_VER.png',
  //       text: `This is the body text of a card.  You can even use line\n  breaks and emoji! 💁`,
  //       buttonText: 'This is a button',
  //       buttonUrl: 'https://assistant.google.com/'
  //     })
  //   );
  //   agent.add(new Suggestion(`Quick Reply`));
  //   agent.add(new Suggestion(`Suggestion`));
  //   agent.setContext({ name: 'weather', lifespan: 2, parameters: { city: 'Rome' }});
  // }

  // // Uncomment and edit to make your own Google Assistant intent handler
  // // uncomment `intentMap.set('your intent name here', googleAssistantHandler);`
  // // below to get this function to be run when a Dialogflow intent is matched
  // function googleAssistantHandler(agent) {
  //   let conv = agent.conv(); // Get Actions on Google library conv instance
  //   conv.ask('Hello from the Actions on Google client library!') // Use Actions on Google library
  //   agent.add(conv); // Add Actions on Google library responses to your agent's response
  // }
  // // See https://github.com/dialogflow/fulfillment-actions-library-nodejs
  // // for a complete Dialogflow fulfillment library Actions on Google client library v2 integration sample

  // Run the proper function handler based on the matched Dialogflow intent name
  let intentMap = new Map();
  intentMap.set('Default Welcome Intent', welcome);
  intentMap.set('Default Fallback Intent', fallback);
  intentMap.set('Recommendation', recommendation);
  intentMap.set('SearchTitleBook', searchTitle);
  intentMap.set('SearchCategoryBook', searchCategory);
  intentMap.set('SearchAuthorBook', searchAuthor);
  intentMap.set('ListCategory', listCategory);
  intentMap.set('Personality', personality);
  intentMap.set('test', Test);
  // intentMap.set('your intent name here', yourFunctionHandler);
  // intentMap.set('your intent name here', googleAssistantHandler);
  agent.handleRequest(intentMap);
});
